Limitações do projeto:
-O qr code não gera uma imagem
-O histórico não é encriptado
-O servidor gera certificados de utilizador corrompidos
-Os scripts de compilação apenas funcionam em linux

Compilação e execução do projeto:
-Para compilar o projeto basta correr o script fornecido "compile", sendo que gera o Trokos.jar e o Server.jar na pasta bin
-Para correr o projeto executa-se os jars, fornecendo os argumentos tal como no enunciado