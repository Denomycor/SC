package network;

public enum ResponseStatus {
	OK, ERROR, TRANSACTION_REQ, OB_QR
}
