package exceptions;

public class TrokosException extends Exception {

	private static final long serialVersionUID = 7005276593922304575L;

	public TrokosException(String msg) {
		super(msg);
	}
}
